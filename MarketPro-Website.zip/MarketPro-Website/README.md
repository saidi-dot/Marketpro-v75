# MarketPro Website

A responsive, static website for a digital marketing business. It uses plain HTML, CSS, and JavaScript, so it does not need a build step or paid framework.

## Files
- `index.html` — website content and sections
- `styles.css` — responsive visual design
- `script.js` — mobile navigation and current footer year

## Before publishing
1. Open `index.html`.
2. Replace `hello@marketpro.example` with your real business email.
3. Update the WhatsApp link in the contact section. Use your full international number without `+`, spaces, or dashes in the URL, for example `https://wa.me/2547XXXXXXXX`.
4. Review the service descriptions and pricing/contact details to ensure they match your actual business. No fake testimonials or performance claims are included.

## Publish free with GitHub Pages (Android phone)
1. Sign in at https://github.com and open your repository.
2. Upload `index.html`, `styles.css`, `script.js`, and `README.md` to the repository's top level (same folder as the README). If asked, confirm the commit.
3. Open the repository's **Settings**.
4. Open **Pages** in the sidebar (on a phone, you may need your browser's desktop-site option).
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose your default branch (often `main`) and folder **/(root)**, then tap **Save**.
7. Wait a few minutes. The Pages screen will show the published website URL. Open it to test the site on your phone.

If your repository already contains an `index.html`, download or review it before replacing it so you do not overwrite work you want to keep.

## Important
The WhatsApp contact link is a generic starter link and the email is intentionally a placeholder. Replace both before sharing the website with customers. GitHub Pages publishes a static site; contact forms that store submissions need a separate form service or backend.
